from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('user_login', views.user_login, name='user_login'),
    path('register', views.register, name='register'),
    path('index', views.index, name='index'),
    path('home', views.home, name='home'),
    path('about', views.about, name='about'),
    path('services', views.services, name='services'),
    path('gallery', views.gallery, name='gallery'),
    path('price', views.price, name='price'),
    path('buynow', views.buynow, name='buynow'),
    path('user_logout' , views.user_logout , name = 'user_logout'),
    path('ourmart', views.ourmart, name='ourmart'),
    
]
