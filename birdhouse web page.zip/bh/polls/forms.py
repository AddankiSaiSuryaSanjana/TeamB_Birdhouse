from django import forms
from django.contrib.auth.models import User
from polls.models import UserProfileInfo

class UserForm(forms.ModelForm):
    class Meta():
        model = UserProfileInfo
        fields = ('username','password','email')
